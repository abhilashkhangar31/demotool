/**
 * 
 */
package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author abhilashk
 *
 */
@Service("customUserDetailsService")
public class UserAuthenticationService implements UserDetailsService {

	private static final String USER_NAME = "user";
	private static final String ADMIN_NAME = "admin";
	private static final String PASSWORD = "$2a$10$T52LEee7ZWNHGSbTgSVJJujOV5fSVD8EVDNv1WazirxxdMDw2gPju";
	
	@Override
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		List<GrantedAuthority> authorities = new ArrayList<>();
		if (username == null || !(username.equals(USER_NAME) || username.equals(ADMIN_NAME))) {
			throw new UsernameNotFoundException("Username not found.");
		}
		if (username.equals(USER_NAME)) {
			authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
			return new User(USER_NAME, PASSWORD, true, true, true, true, authorities);
		}
		authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		return new User(ADMIN_NAME, PASSWORD, true, true, true, true, authorities);
	}

}
