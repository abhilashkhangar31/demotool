var watApp = angular.module("watApp", [ "ngRoute" ]);

watApp.config(function($routeProvider) {
	$routeProvider
	.when("/", {
		templateUrl : "spa/home"
	})
	.when("/home", {
		templateUrl : "spa/home"
	})
	.when("/login", {
		templateUrl : "login"
	})
	.when("/register/user", {
		templateUrl : "register/user"
	})
});

var userRegistrationCtrl = watApp.controller("userRegistrationCtrl", function($scope, $http) {

	$scope.registrationModel = {};
	
	$scope.registerUser = function() {
		console.log($scope.registrationModel);
		$http({
			method : 'POST',
			url : 'register/user',
			data : $scope.registrationModel,
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded'
			}
		}).then(function(result) {
			console.log(result);
		}, function(error) {
			console.log(error);
		}); 
		
	}
});